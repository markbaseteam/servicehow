# Development Criteria
A very unofficial document of things you should understand as a developer

\* Means you can jump In and out or learn as you go but you should do the numbered ones in order

|Sections||
|---|---|
|1) Agile and process|- What is agile?<br>    - What is a sprint?<br>    - What is a story?<br>    - What is a scrum (DSU)?<br>    - What is a retrospective?<br>    - What is TDA and solutioning?<br>    - What is the story process?<br>    - What larger development cycle look like?|
|*^ Extra|- What’s an epic?<br>    - What’s a product?<br>    - What’s a spike? <br>    - What’s an enhancement?<br>    - What’s a defect?|
|2) Basic Development|- What is a table?<br>    - What is a field?<br>    - What is a form?<br>    - What is a reference?<br>    - What is a business rule?<br>    - What is a client script?<br>    - What is a UI policy?<br>    - What is a UI action?<br>    - What is an ACL?<br>    - What is an email notification?|
|3) Catalog items|- What is a catalog? <br>    - What is a catalog item?<br>    - What is a record producer?<br>    - What are variables?<br>    - What are variable sets?<br>    - What are requests and request items?<br>    - What are catalog client scripts and UI policies?|
|*) Knowledge|- What is a knowledge base?<br>    - What is a knowledge article?<br>    - What are common knowledge processes?|
|4) Flow Designer|- What is flow designer?<br>    - What is a flow?<br>    - What is a sub flow?<br>    - What is an action?|
|5) Scripting|- What is client and server side?<br>    - What is the script editor?<br>    - What are common server-side objects?<br>    - What are common client-side objects?<br>    - What is a background script?<br>    - What is client-side scripting? (Client scripts, UI policies and UI actions)<br>    - What is a script include?|
|^Extra|- What is an ajax call?<br>    - What is a scheduled job?<br>    - What is a fix script?|
|6) Change Management|- What a change request?<br>    - What is the change process?<br>    - What is a change template?<br>    - What is a state model?|
